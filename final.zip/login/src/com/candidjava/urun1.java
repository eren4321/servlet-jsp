package com.candidjava;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class urun1
 */
@WebServlet("/urun1")
public class urun1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public urun1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		  {
				String[] urun =request.getParameterValues("urun");		
				PrintWriter out=response.getWriter();
				 
				response.setContentType("text/html");
				HttpSession session=request.getSession(false);  
		        String n=(String)session.getAttribute("uname"); 
				out.print("<html><body>");
				out.print("<h1>�r�nler</h1>");
				out.print("<u1>");
				for(String s: urun)
				{	
					out.print("<li>" +s+"</li>");
					try {
						Class.forName("com.mysql.jdbc.Driver");
					
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root"); 
					
					String query="insert into urun values(?,?)";
					
					PreparedStatement ps=con.prepareStatement(query);  
					
					
					ps.setString(1, n);
					ps.setString(2, s);
				
					
					ps.executeUpdate(); // execute it on test database
					System.out.println("successfuly inserted");
					ps.close();
					con.close();
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				}
				out.print("</u1>");
				out.print("</body></html>");
				
				
			                                                             
			                                                             
			                                                             
			}
		
	}

}}
